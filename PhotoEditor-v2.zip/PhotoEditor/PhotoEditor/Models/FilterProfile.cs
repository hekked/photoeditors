namespace PhotoEditor.Models;

public class FilterProfile
{
    public string Name { get; set; } = string.Empty;
    public double Dullness { get; set; }
    public double Contrast { get; set; }
    public double Brightness { get; set; }
    public double Saturation { get; set; }
}
