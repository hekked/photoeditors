using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Media.Imaging;
using Avalonia.Platform.Storage;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using PhotoEditor.Models;

namespace PhotoEditor.ViewModels;

public partial class MainWindowViewModel : ViewModelBase
{
    [ObservableProperty]
    private string _currentFileName = "Без названия.png";

    [ObservableProperty]
    private string _statusText = "Готово к работе";

    [ObservableProperty]
    private double _dullness = 0;

    [ObservableProperty]
    private double _contrast = 100;

    [ObservableProperty]
    private double _brightness = 0;

    [ObservableProperty]
    private double _saturation = 100;

    [ObservableProperty]
    private double _sharpness = 0;

    [ObservableProperty]
    private double _canvasOpacity = 1.0;

    [ObservableProperty]
    private bool _isImageLoaded = false;

    [ObservableProperty]
    private Bitmap? _loadedBitmap;

    [ObservableProperty]
    private FilterProfile? _selectedPreset;

    public ObservableCollection<FilterProfile> Presets { get; } = new()
    {
        new FilterProfile { Name = "Оригинал", Dullness = 0, Contrast = 100, Brightness = 0, Saturation = 100 },
        new FilterProfile { Name = "Винтаж", Dullness = 35, Contrast = 85, Brightness = -5, Saturation = 70 },
        new FilterProfile { Name = "Холодный мат", Dullness = 50, Contrast = 110, Brightness = 0, Saturation = 60 }
    };

    partial void OnSelectedPresetChanged(FilterProfile? value)
    {
        if (value is null) return;
        Dullness = value.Dullness;
        Contrast = value.Contrast;
        Brightness = value.Brightness;
        Saturation = value.Saturation;
        StatusText = $"Применен пресет: {value.Name}";
    }

    partial void OnDullnessChanged(double value)
    {
        CanvasOpacity = 1.0 - (value / 200.0);
        UpdatePreviewBuffer();
    }

    partial void OnContrastChanged(double value)
    {
        UpdatePreviewBuffer();
    }

    partial void OnBrightnessChanged(double value)
    {
        UpdatePreviewBuffer();
    }

    partial void OnSaturationChanged(double value)
    {
        UpdatePreviewBuffer();
    }

    private void UpdatePreviewBuffer()
    {
        StatusText = $"Изменено: Тусклость {Dullness:F0}%, Контраст {Contrast:F0}%";
    }

    [RelayCommand]
    private async Task OpenFile()
    {
        if (Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop &&
            desktop.MainWindow is not null)
        {
            var files = await desktop.MainWindow.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Открыть изображение",
                AllowMultiple = false,
                FileTypeFilter = new[] { FilePickerFileTypes.ImageAll }
            });

            if (files.Count >= 1)
            {
                await using var stream = await files[0].OpenReadAsync();
                LoadedBitmap = new Bitmap(stream);
                CurrentFileName = files[0].Name;
                IsImageLoaded = true;
                StatusText = $"Загружен файл: {CurrentFileName}";
            }
        }
    }

    [RelayCommand]
    private void SaveFile()
    {
        StatusText = "Модуль сохранения еще не подключен";
    }

    [RelayCommand]
    private void ResetFilters()
    {
        SelectedPreset = null;
        Dullness = 0;
        Contrast = 100;
        Brightness = 0;
        Saturation = 100;
        Sharpness = 0;
        CanvasOpacity = 1.0;
        StatusText = "Настройки сброшены";
    }

    [RelayCommand]
    private void OpenCurvesTool()
    {
        StatusText = "Инструмент 'Кривые' будет добавлен в следующей версии";
    }
}
