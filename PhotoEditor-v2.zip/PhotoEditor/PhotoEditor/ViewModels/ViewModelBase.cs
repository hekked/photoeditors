using CommunityToolkit.Mvvm.ComponentModel;

namespace PhotoEditor.ViewModels;

public class ViewModelBase : ObservableObject
{
}
